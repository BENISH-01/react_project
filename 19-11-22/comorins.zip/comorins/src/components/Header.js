import React, { useContext } from 'react'
import  'bootstrap/dist/css/bootstrap.min.css'
import {Link,  useNavigate} from 'react-router-dom'
import UserContext from '../pages/context'
import '../App.css'

function Header(){
 const value=useContext(UserContext)
 const navigate=useNavigate()

 const changelocal=()=>{
    value.setisLogin(false)
    localStorage.setItem('login-course',false)
    localStorage.setItem('user-course','')
    navigate('/')
 }
    return(<>
      <nav className="navbar navbar-expand-lg navbar-light bg-warning d-flex justify-content-around head-bar">
                <button className="btn  ">
                   <Link className="nav-link" to={'/Home'}>Home</Link>
                </button>
                <button className="btn ">
                   <Link className="nav-link" to={'/Createcourse'}>Create-course</Link>
                </button>
                <button className="btn ">
                    <Link className="nav-link" to={'/Users'}>Users-list</Link>
                </button>
            
            <span className="navbar-text">
               <button className=" btn btn-danger one" onClick={changelocal}>Logout</button>
            </span>
        
      </nav>
    </>)
}
export default Header