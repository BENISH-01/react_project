import {useEffect,useState} from 'react'
import axios from 'axios'
import { useNavigate,Link } from 'react-router-dom'
import '../App.css'




function Coursedetails(){
    const[courseList,setcourseList]=useState([])
useEffect(()=>{
    getCourse()
},[])

    const getCourse=async()=>{
        const {data}=await axios.get("https://karka.academy/api/action.php?request=getCourses")
         setcourseList(data.data)
    
    }




    return(<>
    
    
    
  
    {courseList.map((item,index)=>{
        return(
            <div className='card'>
                <div className='card-body '>
                    <Link className='link' to={`/Singlecourse/${item.id}`}><h4>{index+1}.{item.name}</h4></Link>
                </div>

            </div>
        )
    })}
    
    </>)
}
export default Coursedetails