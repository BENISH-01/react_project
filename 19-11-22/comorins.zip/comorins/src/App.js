import logo from './logo.svg';
import './App.css';
import React, { useState } from 'react'


import MainRoutes from './routes';

function App() {

  
  return (
    <div className="App">
     
     <MainRoutes/>
     
    </div>
  );
}

export default App;
