import React, { useState } from 'react'
import  'bootstrap/dist/css/bootstrap.min.css'
import '../App.css';
import axios from 'axios';
import {Link,useNavigate} from 'react-router-dom'





function Register(){

   const navigate=useNavigate()

    const[regiser,setRegister]=useState({
        request : 'create_candidate',
        name : '',
        email : '',
        password : '',
        aadhar : '',
        address : '',
        phone:'',
        city:'',
        area:'',
        pin:'',
        })

        const submit=async()=>{
            const data=await axios.post("https://karka.academy/api/action.php?",JSON.stringify(regiser))
            console.log(data)
            if(data){
                navigate('/')
            }
        }
     return(<div>
      
      <h2 className='text-center'>Please fill your Details!!!</h2>
     <div className='container display-form '>
     <form>
        NAME:<input className='form-control' onChange={(e)=>setRegister({...regiser,name:e.target.value})}/>
        EMAIL:<input className='form-control' onChange={(e)=>setRegister({...regiser,email:e.target.value})}/>
        PASSWORD:<input className='form-control' onChange={(e)=>setRegister({...regiser,password:e.target.value})}/>
        AADHAR:<input className='form-control' onChange={(e)=>setRegister({...regiser,aadhar:e.target.value})}/>
        ADDRESS:<input className='form-control' onChange={(e)=>setRegister({...regiser,address:e.target.value})}/>
        PHONE:<input className='form-control' onChange={(e)=>setRegister({...regiser,phone:e.target.value})}/>
        CITY:<input className='form-control' onChange={(e)=>setRegister({...regiser,city:e.target.value})}/>
        AREA:<input className='form-control' onChange={(e)=>setRegister({...regiser,area:e.target.value})}/>
        PIN:<input className='form-control' onChange={(e)=>setRegister({...regiser,pin:e.target.value})}/>
        <button type='button' className='btn btn-primary mt-3 col-12' onClick={submit}>Submit</button>
     </form>
     </div>

   </div>)
 }
 export default Register