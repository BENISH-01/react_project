import React, { useEffect, useState } from 'react'
import axios from 'axios'


function Users(){

    const[Users,setUsers]=useState()

    useEffect(()=>{
        getMembers()
    },[])

    const getMembers=async()=>{
        const {data}=await axios.get("https://karka.academy/api/action.php?request=getAllMembers")
          console.log(data.data)
         let full_detail=data.data
        setUsers(full_detail)
        
    }



    return(<div>
        
        {Users && Users.map((items,index)=>{
            return(
              <div className='user container'>
                <div key={index} >
                    <div className='card'>
                        <div className='card-body '>
                            <h4>{index+1}.{items.name}</h4>
                        </div>

                    </div>
                </div>
            </div>
           )
        })}
    </div>)
}

export default Users