import React,{useEffect,useState,useContext} from 'react'
import Header from '../components/Header'
import { useNavigate,Link } from 'react-router-dom'
import Coursedetails from '../components/Coursedetails'
import UserContext from './context'
import Users from './Users'








function Home(){

    const value = useContext(UserContext)
    
    
    const navigate=useNavigate();
    const locallog=localStorage.getItem('login-course')
    const localuser=localStorage.getItem('user-course')

    useEffect(()=>{
        if( locallog=='true' || value.isLogin ){
            navigate('/Home')
        }
        else{navigate('/')}
        
    },[value.isLogin])






    return(<>
    
    <h2 className='text-center'> welcome { localuser}</h2>
    <Header />
    <div className='container second-body'>
    <div className='row '>
        <div className='col-6'>
            <h3 className='text-center'>COURSE-LIST</h3>
        </div>
        <div className='col-6'>
           <h3 className='text-center'>USERS-LIST</h3>
        </div>
    </div>
    
    <div className='row'>
        <div className='col-6'>
        <Coursedetails/>
        </div>
        <div className='col-6'>
            <Users/>
        </div>
    </div>
    </div>
    
    
    
    </>)
}
export default Home