import React,{ useState ,useEffect,useContext} from "react"
import  'bootstrap/dist/css/bootstrap.min.css'
import axios from "axios"
import UserContext from "./context"
import {  useNavigate } from 'react-router-dom'

  
  
  function Createcourse(){

    const value = useContext(UserContext)
    const locallog=localStorage.getItem('login-course')
    
    const navigate=useNavigate()

    useEffect(()=>{
        if(!value.isLogin && locallog==false){
            navigate('/')
        }
    },[value.isLogin])

   const[Createcourse,setCreatecourse]=useState({
    request : 'create_course',
    name : '',
    video_id :'',
    description:'',
    price :'',
    })


    const create_course=async()=>{
      const response=await axios.post('https://karka.academy/api/action.php?',JSON.stringify(Createcourse))
      console.log(response)
    }
    return(<>
      <h2 className="text-center"> Please Fill Course Details</h2>
      <div className=" container row mb-2">
        <div className="col-3"><h3>Course-Name:</h3></div>
        <div className="col-8"><input className="form-control" onChange={(e)=>setCreatecourse({...Createcourse,name:e.target.value})}/></div>
      </div>
      <div className=" container row mb-2">
        <div className="col-3"><h3>Video-Id:</h3></div>
        <div className="col-8"><input className="form-control" onChange={(e)=>setCreatecourse({...Createcourse,video_id:e.target.value})}/></div>
      </div>
      <div className=" container row mb-2">
        <div className="col-3"><h3>Description:</h3></div>
        <div className="col-8"><input className="form-control" onChange={(e)=>setCreatecourse({...Createcourse,description:e.target.value})}/></div>
      </div>
      <div className=" container row mb-2">
        <div className="col-3"><h3>Price:</h3></div>
        <div className="col-8"><input className="form-control" onChange={(e)=>setCreatecourse({...Createcourse,price:e.target.value})}/></div>
      </div>
      <button type="button" className="btn btn-success ml-5" onClick={create_course}>Create course</button>
    </>)
  }
  export default Createcourse