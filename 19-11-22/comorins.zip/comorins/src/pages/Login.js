import React, { useEffect, useState,useContext } from 'react'
import axios from'axios'
import  'bootstrap/dist/css/bootstrap.min.css'
import {Link,useNavigate} from 'react-router-dom'
import UserContext from './context'



function Login(){
  const value = useContext(UserContext)
  const locallog=localStorage.getItem('isLogin')
    
    
  const navigate=useNavigate()
  useEffect(()=>{
    if(value.isLogin || locallog=='true'){
        navigate('/Home')
    }
},[value.isLogin])

 
 

    const[userdata,setData]=useState({
            request : 'candidate_login',
            email : '',
            password : ''
        })
       
        const verify=async()=>{
            const {data}=await axios.post("https://karka.academy/api/action.php?",JSON.stringify(userdata))
            
            if(data.status=='success'){
               value.setisLogin(true)
               value.setcurrentUser(data.data)
               localStorage.setItem('login-course',true)
               localStorage.setItem('user-course',data.data.name)
                navigate('/Home')
              
            }
        
        }

    return(<>
      <div className='container  input_form text-center'>
      <input className='form-control mb-2' placeholder='Enter your email' onChange={(e)=>setData({...userdata,email:e.target.value})}/>
      <input className='form-control mb-2' placeholder='Enter password' onChange={(e)=>setData({...userdata,password:e.target.value})}/>
      <button className='btn btn-success' type='button' onClick={verify}>Login</button>
      <Link to="/Register"> New user? Register Here</Link>
      </div>
    </>)
}
export default Login