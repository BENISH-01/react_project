import axios from 'axios'
import React,{useState, useEffect,useContext} from 'react'
import {useNavigate, useParams} from 'react-router-dom'
import Coursedetails from '../components/Coursedetails'
import  'bootstrap/dist/css/bootstrap.min.css'
import Header from '../components/Header'
import UserContext from './context'
import '../App.css'


function Singlecourse(){
    const value = useContext(UserContext)
    
   
    const[Course,setCourse]=useState({})

    const params=useParams()
    const navigate=useNavigate()
    const locallog=localStorage.getItem('isLogin')
    console.log(Course)
    useEffect(()=>{
       
        
        getsingleCourse(params.id)
    },[value.isLogin,params.id])

    const getsingleCourse=async()=>{
       const{data}=await axios.get( `http://karka.academy/api/action.php?request=getCourseDetails&id=${params.id}`)
       setCourse(data.data)
    }
    
    return(<>
       <h3 className='text-center'>Welcome {value.currentUser.name}</h3>
       <Header />
       
       <div className='container second-body'>
                <div className='row '>
                <div className='col-4'><Coursedetails/></div>
               
                    <div className='col-8 card '>
                       <div className='row mt-5 '>
                            <div className='col-6'>
                                <h3>Course Id :</h3>
                            </div>
                            <div className='col-6'>
                                <h3>{Course.id}</h3>
                            </div>
                            
                        </div>
                        <div className='row'>
                            <div className='col-6'>
                                <h3>Course :</h3>
                            </div>
                            <div className='col-6'>
                                <h3>{Course.name}</h3>
                            </div>
                            
                        </div>
                        <div className='row'>
                            <div className='col-6'>
                                <h3>Price :</h3>
                            </div>
                            <div className='col-6'>
                                <h3>{Course.price}</h3>
                            </div>
                            
                        </div>
                        <div className='row'>
                            <div className='col-6'>
                                <h3>Video :</h3>
                            </div>
                            <div className='col-6'>
                                <h3>{Course.video_id}</h3>
                            </div>
                            
                        </div>
                        <div className='row'>
                            <div className='col-6'>
                                <h3>Description:</h3>
                            </div>
                            <div className='col-6'>
                                <h3>{Course.description}</h3>
                            </div>
                            
                        </div>
                    </div>
                </div>
                
            
       </div>
       
    </>)

}

export default Singlecourse