import React, { useState,useContext } from 'react'
import {
    BrowserRouter as Router,
    Routes,
    Route
} from 'react-router-dom'
import Home from './pages/Home'
import Login from './pages/Login'
import Singlecourse from './pages/Singlecourse'
import Register from './pages/Register'
import Createcourse from './pages/Createcourse'
import UserContext from './pages/context'
import Users from './pages/Users'


function MainRoutes(){
    const [isLogin,setisLogin]=useState(false)
    const [currentUser,setcurrentUser]=useState({})
    return(
      <UserContext.Provider value={{isLogin,setisLogin,currentUser,setcurrentUser}}>
          <Router>
            <Routes>
               <Route path='/'  element={<Login/>} />
               <Route path='/Home' element={<Home/>} />
               <Route path='/SingleCourse/:id' element={<Singlecourse/>}/>
               <Route path='/Register' element={<Register/>}/>
               <Route path='/Createcourse' element={<Createcourse />}/>
               <Route path='/Users' element={<Users />}/>
            </Routes>
        </Router>
      </UserContext.Provider>
    )
}

export default MainRoutes