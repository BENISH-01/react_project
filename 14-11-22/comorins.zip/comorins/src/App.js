import logo from './logo.svg';
import './App.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import Register  from './Pages/Register';
import Login from './Pages/Login';
import { useState } from 'react';
import Home from './Pages/Home';


function App() {

  const[islogin,setLogin]=useState(false)
  const[register,setRegister]=useState([ 
    // {email:'comorins',
    // pass:123}
   { request : "candidate_login",
    email : "jegan",
     pass : 1234567890}
  ])
  return (
    <Router>
    <div>
      <nav>
        <ul>
 
  
        </ul>
      </nav>

      {/* A <Switch> looks through its children <Route>s and
          renders the first one that matches the current URL. */}
      <Switch>
        <Route path="/" exact>
          <Login setLogin={setLogin}  register={register} islogin={islogin}/>
        </Route>
        <Route  >
          <Register  path="/Register" register={register} setRegister={setRegister} />
        </Route>
       

        <Route path="/Home">
          <Home />
        </Route>
        
      </Switch>
    </div>
  </Router>
);
}





export default App;
