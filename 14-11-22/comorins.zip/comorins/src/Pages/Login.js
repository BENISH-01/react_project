import React, { useState,useHistory } from "react";
import { Link,useHistory } from "react-router-dom";





function Login({setLogin,register}){
    const history=useHistory()

    const[email,setEmail]=useState('')
    const[pass,setPass]=useState('')
    let data={
        
            request : 'candidate_login',
            email : 'jegan',
            password : 1234567890
            
    }

const Verify=()=>{
    //    register.map((values)=>{
        if(data.email==email && data.password==pass){
            // console.log('success')
        //     // history.push({pathname:'/Home',
        //     // search:email,
        //     // state: { detail:values.email }
        // })
        console.log("data",data)
            fetch("http://karka.academy/api/action.php",{
                method:'POST',
                body:JSON.stringify(data),
                headers:{
                    'Content-Type': 'application/json'
                }

            }).then((data)=>data.json())
            .then((response)=>console.log(response))
        }
    //  })
}

    return(<>
    <h2>This is log in page</h2><br/>
    <input placeholder="enter your email" onChange={(e)=>{setEmail(e.target.value)}}/><br/>
    <input placeholder="enter your password" onChange={(e)=>{setPass(e.target.value)}}/><br/>
    <button onClick={Verify} >Login</button>

    <li><Link to="/Register">Register</Link></li>
    
    </>)
}

export default Login;