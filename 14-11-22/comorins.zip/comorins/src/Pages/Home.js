import React from "react";
import { useLocation } from "react-router-dom"

function Home(){
    
    const location=useLocation()
    console.log(location.search)
    console.log(location.state.detail)

    return(<>
    <h2>This is home page</h2></>
    )
}
export default Home