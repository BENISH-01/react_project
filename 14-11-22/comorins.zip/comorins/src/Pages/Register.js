import React, { useState } from "react";




function Register({setRegister,register}){

    const[RegisterEmail,setRegisterEmail]=useState('')
    const[RegisterPass,setRegisterPass]=useState('')

 const Submit=()=>{
    let update={
         email:RegisterEmail,
         pass:RegisterPass
     }
    setRegister(update)
}

    return(<>
    <h2>This is Register page</h2>
    <input placeholder="enter your name"/>
    <input placeholder="enter your gmail" onChange={(e)=>{setRegisterEmail(e.target.value)}}/>
    <input placeholder="enter your phone"/>
    <input placeholder="enter your password" onChange={(e)=>{setRegisterPass(e.target.value)}}/>
    <button onClick={Submit}>Submit</button>
    
    </>)
}


export default Register