import Carousel from "./Carousel"



function Banner(){


    return(<>
    <div className="bannerimg ">
       <div className="banner-content ">
         <h2> Crypto Hunter</h2>
         <p>Get All The Info Regarding Your Crypto Currencies</p>
        
        </div> 
        <Carousel/>
        </div>
        
  
    </>)
}


export default Banner