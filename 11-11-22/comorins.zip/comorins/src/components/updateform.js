import '../App.css'
const Updateform=({changeTask,setupdateTask,updateTask,updatedObject})=>{
   return(<>
    <div className='col-9'>
    <input value={updateTask && updateTask.title} className='form-control form-control-lg' onChange={(e)=>{changeTask(e)}}/>
   </div>
   <div className='col'>
    <button className='btn btn-primary btn-lg' onClick={updatedObject}>Update</button>
    <button className='btn btn-secondary btn-lg ml-3'onClick={()=>{setupdateTask('')}}>Cancel</button>
   </div>
 
  </> )
}
export default Updateform