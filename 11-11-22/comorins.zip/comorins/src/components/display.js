import React from 'react'
import '../App.css'
import  {FontAwesomeIcon} from '@fortawesome/react-fontawesome'
import {
  faCircleCheck, faPen, faTrashCan
} from '@fortawesome/free-solid-svg-icons'

const Display=({Todo,markDone,setupdateTask,Delete})=>{
    return(<>
      {Todo && Todo
      .sort((a,b)=>a.id>b.id? 1 :-1)
      .map((task,index)=>{
          return(<>
          <div className='row'>
               <div className='col task_bg '>
                <div className={task.status? 'done':''}>
                  <p className='task_width'>{index+1} {task.title}</p>
                 </div> 
              </div>
                 <div className='col icons'>
                  <span className='span1' icon={faCircleCheck} onClick={()=>markDone(task.id)}><FontAwesomeIcon icon={faCircleCheck}/></span>

                   {!task.status? <span className='span2' onClick={()=>{setupdateTask({id:task.id,title:task.title,status:task.status? true:false})}}><FontAwesomeIcon icon={faPen}/></span>:null}

                  <span className='span3' onClick={()=>Delete(task.id)}><FontAwesomeIcon icon={faTrashCan}/></span>
                </div>


               
               </div>
          </>)
      })}
      </>)
}
export default Display