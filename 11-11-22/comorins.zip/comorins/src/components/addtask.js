import '../App.css'
const AddTaskform=({newTask,setnewTask,Addtask})=>{
    return(<>
        <div className='row mt-2'>
            <div className='col-10'>
            <input value={newTask} onChange={(e)=>{setnewTask(e.target.value)}} className='form-control form-control-lg' />
            </div>
            <div className='col'>
            <button className='btn btn-success btn-lg' onClick={Addtask}>Add</button>
            </div>
        </div>
   </>)
    
}
export default AddTaskform