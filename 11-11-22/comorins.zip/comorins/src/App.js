import React from 'react';
import {useState} from 'react'
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'
import  {FontAwesomeIcon} from '@fortawesome/react-fontawesome'
import {
  faCircleCheck, faPen, faTrashCan
} from '@fortawesome/free-solid-svg-icons'
import Updateform  from './components/updateform';
import AddTaskform from './components/addtask';
import Display from './components/display';

function App() {
  // task state
  const[Todo,setTodo]=useState([
    // {id:1,title:"todo1",status:false},
    // {id:2,title:"todo2",status:false}
  ])

  // set task
  const[newTask,setnewTask]=useState('')
  const[updateTask,setupdateTask]=useState('')

  // addtask
  const Addtask=()=>{
    if(newTask){
      let num=Todo.length+1;
      let newEntry={id:num,title:newTask,status:false}
      setTodo([...Todo,newEntry])
      setnewTask('')
    }
  }
  // delete task
  const Delete=((id)=>{
      let newTasks_after_delete=Todo.filter(values=>values.id!==id)
      setTodo(newTasks_after_delete)
  })
  // clear complete
  const markDone=(id)=>{
    let clear_completed=Todo.map((values)=>{
      if(values.id===id){
        return({...values,status:!values.status})
      }
      return values
    })
    setTodo(clear_completed)
  }
  // edit todo
  const changeTask=((e)=>{
    let upd={
      id:updateTask.id,
      title:e.target.value,
      status:updateTask.status? true:false
    }
    setupdateTask(upd)
  })
  // update todo
  const updatedObject=()=>{
    let filter_records=Todo.filter(values=>values.id!==updateTask.id)
   let updated_records=[...filter_records,updateTask]
   setTodo(updated_records)
   setupdateTask('')
  }
  
  


  return (
    <div className="App container">
       <h1 className='text-danger text-center'>TODO LIST</h1>
       {/* update form */}
     {updateTask && updateTask?(<>
        <div className='row'>

              <Updateform changeTask={changeTask} setupdateTask={setupdateTask} updateTask={updateTask} updatedObject={updatedObject}/>

        </div>
        </>):
        <AddTaskform newTask={newTask} setnewTask={setnewTask} Addtask={Addtask}/> }
       
       

         
      {/* display */}

      {Todo && Todo.length?'':'No Tasks to Show...'}
      <Display Todo={Todo} markDone={markDone} setupdateTask={setupdateTask} Delete={Delete} />
      
    
    </div>
  );
}

export default App;
